RIDAH VENTURES — FREE WEBSITE PACKAGE

Files
- index.html: the website. Open it in a browser to preview.

Before publishing
1. Open index.html in a text editor.
2. Find the QUICK SETUP comments near the bottom of the file.
3. Replace RIDAH_WHATSAPP_NUMBER = '' with your WhatsApp number in international format using digits only. Example India number: '919876543210' (country code 91, then your number; no +, spaces, or dashes).
4. Replace RIDAH_INSTAGRAM_USERNAME = '' with your Instagram username, without the @.
5. Save the file and upload the updated index.html.

No business email was provided, so the site uses WhatsApp and Instagram as requested. No contact details have been invented. Until you add the details, the buttons explain that links are not yet configured.

Publish for free using GitHub Pages
1. Sign in or create a free account at https://github.com/
2. Create a new PUBLIC repository, for example: ridah-ventures-website
3. Upload index.html to the top/root level of the repository (not inside another folder).
4. Open the repository's Settings → Pages.
5. Under Build and deployment, select “Deploy from a branch”.
6. Choose branch “main” and folder “/(root)”, then Save.
7. Wait a few minutes. GitHub will show your public website URL in the Pages section, usually: https://YOUR-USERNAME.github.io/ridah-ventures-website/

Notes
- GitHub Pages hosting is free for public repositories.
- A custom domain such as ridahventures.com is optional and usually costs extra.
- This is a showcase website, not an online store; it does not include checkout or payment processing.
- Test the website and contact buttons after publishing.
