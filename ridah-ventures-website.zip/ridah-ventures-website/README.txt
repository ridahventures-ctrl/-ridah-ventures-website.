RIDAH VENTURES WEBSITE

Files:
- index.html: complete responsive one-page website. Open it in a browser to preview.

BEFORE PUBLISHING:
1. Open index.html in a text editor.
2. Find 91XXXXXXXXXX and replace it with your WhatsApp number including country code, digits only (example format: 919876543210).
3. Replace hello@ridahventures.com with your actual business email.
4. Save the file.

FREE HOSTING OPTION (GitHub Pages):
1. Sign in or create a free account at https://github.com
2. Create a new public repository named ridah-ventures-website.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. After GitHub publishes it, the Pages section will show your free website URL.

The site is a product showcase and enquiry landing page. It does not yet have online checkout or product inventory.
